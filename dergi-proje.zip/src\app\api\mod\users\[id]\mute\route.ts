import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { cookies } from 'next/headers'
import { verifyToken } from '@/lib/session'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Kullanıcıyı ve rollerini getir
    const user = await prisma.user.findUnique({
      where: { id: payload.uid },
      include: {
        roles: {
          include: {
            role: true
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Moderator yetkisi kontrolü
    const isModerator = user.roles.some(r => 
      ['moderator', 'admin', 'owner'].includes(r.role.name.toLowerCase())
    )

    if (!isModerator) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { duration, reason } = await request.json()
    const targetUserId = parseInt(params.id)

    if (!duration || !reason) {
      return NextResponse.json({ error: 'Duration and reason are required' }, { status: 400 })
    }

    // Hedef kullanıcıyı getir
    const targetUser = await prisma.user.findUnique({
      where: { id: targetUserId }
    })

    if (!targetUser) {
      return NextResponse.json({ error: 'Target user not found' }, { status: 404 })
    }

    // Susturma süresini hesapla
    const muteUntil = new Date()
    muteUntil.setDate(muteUntil.getDate() + duration)

    // Susturma kaydı oluştur (basit bir log sistemi)
    // Gerçek uygulamada ayrı bir Mute tablosu olabilir
    console.log(`User ${user.name} muted user ${targetUser.name} until ${muteUntil}. Reason: ${reason}`)

    return NextResponse.json({
      success: true,
      message: 'Kullanıcı başarıyla susturuldu',
      mute: {
        targetUserId,
        moderatorId: user.id,
        duration,
        reason,
        muteUntil: muteUntil.toISOString(),
        timestamp: new Date().toISOString()
      }
    })
  } catch (error) {
    console.error('Error muting user:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

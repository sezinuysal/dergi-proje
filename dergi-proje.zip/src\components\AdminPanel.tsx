'use client'

import { useState, useEffect } from 'react'

interface User {
  id: number
  name: string
  email: string
  roles: Array<{
    role: {
      id: number
      name: string
      description: string
      color: string
      icon: string
    }
  }>
}

interface Role {
  id: number
  name: string
  description: string
  color: string
  icon: string
}

interface PurchaseRequest {
  id: number
  userId: number
  publicationId: number
  status: string
  paymentMethod?: string
  amount?: number
  notes?: string
  createdAt: string
  user: {
    id: number
    name: string
    email: string
  }
  publication: {
    id: number
    title: string
    type: string
  }
}

interface AdminPanelProps {
  currentUser: User
}

export default function AdminPanel({ currentUser }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'users' | 'roles' | 'purchases'>('users')
  const [users, setUsers] = useState<User[]>([])
  const [roles, setRoles] = useState<Role[]>([])
  const [purchaseRequests, setPurchaseRequests] = useState<PurchaseRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [selectedRole, setSelectedRole] = useState<number | null>(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [usersRes, rolesRes, purchasesRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/admin/roles'),
        fetch('/api/admin/purchases')
      ])

      if (usersRes.ok) {
        const usersData = await usersRes.json()
        setUsers(usersData)
      }

      if (rolesRes.ok) {
        const rolesData = await rolesRes.json()
        setRoles(rolesData)
      }

      if (purchasesRes.ok) {
        const purchasesData = await purchasesRes.json()
        setPurchaseRequests(purchasesData)
      }
    } catch (error) {
      console.error('Veri yüklenirken hata:', error)
    }
    setLoading(false)
  }

  const handleAssignRole = async () => {
    if (!selectedUser || !selectedRole) return

    try {
      const response = await fetch('/api/admin/roles/assign', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: selectedUser.id,
          roleId: selectedRole,
        }),
      })

      if (response.ok) {
        alert('Rol başarıyla atandı!')
        fetchData() // Verileri yenile
        setSelectedUser(null)
        setSelectedRole(null)
      } else {
        const error = await response.json()
        alert(`Hata: ${error.error}`)
      }
    } catch (error) {
      console.error('Rol atama hatası:', error)
      alert('Rol atanırken bir hata oluştu')
    }
  }

  const handleApprovePurchase = async (purchaseId: number) => {
    try {
      const response = await fetch('/api/purchase/approve', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          purchaseRequestId: purchaseId,
        }),
      })

      if (response.ok) {
        alert('Satın alma onaylandı ve dijital erişim sağlandı!')
        fetchData() // Verileri yenile
      } else {
        const error = await response.json()
        alert(`Hata: ${error.error}`)
      }
    } catch (error) {
      console.error('Satın alma onaylama hatası:', error)
      alert('Satın alma onaylanırken bir hata oluştu')
    }
  }

  const handleRejectPurchase = async (purchaseId: number) => {
    try {
      const response = await fetch('/api/admin/reject-purchase', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          purchaseRequestId: purchaseId,
        }),
      })

      if (response.ok) {
        alert('Satın alma reddedildi!')
        fetchData() // Verileri yenile
      } else {
        const error = await response.json()
        alert(`Hata: ${error.error}`)
      }
    } catch (error) {
      console.error('Satın alma reddetme hatası:', error)
      alert('Satın alma reddedilirken bir hata oluştu')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-8 px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-light text-gray-800">Yönetici Paneli</h1>
          <p className="text-gray-600 mt-2">Hoş geldiniz, {currentUser.name}</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 bg-white rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-6 py-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'users' 
                ? 'bg-black text-white' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Kullanıcılar
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={`px-6 py-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'roles' 
                ? 'bg-black text-white' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Rol Atama
          </button>
          <button
            onClick={() => setActiveTab('purchases')}
            className={`px-6 py-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'purchases' 
                ? 'bg-black text-white' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Satın Alma İstekleri
          </button>
        </div>

        {/* Kullanıcılar Tab */}
        {activeTab === 'users' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-light text-gray-800">Kullanıcı Listesi</h2>
            </div>
            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Kullanıcı
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Roller
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        İşlemler
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {users.map((user) => (
                      <tr key={user.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{user.name}</div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-wrap gap-2">
                            {user.roles.map((userRole) => (
                              <span
                                key={userRole.role.id}
                                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                                style={{ 
                                  backgroundColor: userRole.role.color + '20',
                                  color: userRole.role.color 
                                }}
                              >
                                {userRole.role.name}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => setSelectedUser(user)}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            Rol Ata
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Rol Atama Tab */}
        {activeTab === 'roles' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-light text-gray-800">Rol Atama</h2>
            </div>
            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Kullanıcı Seçin
                  </label>
                  <select
                    value={selectedUser?.id || ''}
                    onChange={(e) => {
                      const userId = parseInt(e.target.value)
                      const user = users.find(u => u.id === userId)
                      setSelectedUser(user || null)
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                  >
                    <option value="">Kullanıcı seçin...</option>
                    {users.map((user) => (
                      <option key={user.id} value={user.id}>
                        {user.name} ({user.email})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Rol Seçin
                  </label>
                  <select
                    value={selectedRole || ''}
                    onChange={(e) => setSelectedRole(parseInt(e.target.value) || null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                  >
                    <option value="">Rol seçin...</option>
                    {roles.map((role) => (
                      <option key={role.id} value={role.id}>
                        {role.name} - {role.description}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="mt-6">
                <button
                  onClick={handleAssignRole}
                  disabled={!selectedUser || !selectedRole}
                  className="px-4 py-2 bg-black text-white rounded-md hover:bg-gray-800 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  Rol Ata
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Satın Alma İstekleri Tab */}
        {activeTab === 'purchases' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-light text-gray-800">Satın Alma İstekleri</h2>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                {purchaseRequests.map((request) => (
                  <div key={request.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-medium text-gray-900">{request.publication.title}</h3>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        request.status === 'approved' ? 'bg-green-100 text-green-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {request.status === 'pending' ? 'Bekliyor' :
                         request.status === 'approved' ? 'Onaylandı' : 'Reddedildi'}
                      </span>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600 mb-4">
                      <div>
                        <span className="font-medium">Kullanıcı:</span> {request.user.name} ({request.user.email})
                      </div>
                      <div>
                        <span className="font-medium">Dergi Türü:</span> {request.publication.type}
                      </div>
                      <div>
                        <span className="font-medium">Tarih:</span> {new Date(request.createdAt).toLocaleDateString('tr-TR')}
                      </div>
                      {request.paymentMethod && (
                        <div>
                          <span className="font-medium">Ödeme Yöntemi:</span> {request.paymentMethod}
                        </div>
                      )}
                      {request.amount && (
                        <div>
                          <span className="font-medium">Tutar:</span> {request.amount} TL
                        </div>
                      )}
                    </div>
                    
                    {request.notes && (
                      <div className="mb-4 p-3 bg-gray-50 rounded-md">
                        <span className="font-medium text-sm text-gray-700">Notlar:</span>
                        <p className="text-sm text-gray-600 mt-1">{request.notes}</p>
                      </div>
                    )}

                    {request.status === 'pending' && (
                      <div className="flex space-x-3">
                        <button
                          onClick={() => handleApprovePurchase(request.id)}
                          className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                        >
                          Onayla (Dijital Erişim Ver)
                        </button>
                        <button
                          onClick={() => handleRejectPurchase(request.id)}
                          className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                        >
                          Reddet
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userName, setUserName] = useState('')
  const [userRoles, setUserRoles] = useState<string[]>([])
  const [showLogoutModal, setShowLogoutModal] = useState(false)
  const [showProfileDropdown, setShowProfileDropdown] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Session cookie'den kullanıcı durumunu kontrol et
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/me')
        if (response.ok) {
          const user = await response.json()
          setIsLoggedIn(true)
          setUserName(user.name)
          // Kullanıcı rollerini al
          if (user.roles) {
            const roleNames = user.roles.map((r: any) => r.role.name.toLowerCase())

            setUserRoles(roleNames)
            console.log('User logged in:', user.name, 'Roles:', roleNames) // Debug için
          }
        } else {
          console.log('User not logged in, response status:', response.status) // Debug için
        }
      } catch (error) {
        setIsLoggedIn(false)
      }
    }
    
    checkAuth()
  }, [])

  // Dropdown'ı dışarı tıklayınca kapat
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (showProfileDropdown) {
        const target = event.target as HTMLElement
        if (!target.closest('.profile-dropdown')) {
          setShowProfileDropdown(false)
        }
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [showProfileDropdown])

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      setIsLoggedIn(false)
      setUserName('')
      setShowLogoutModal(false)
      window.location.href = '/'
    } catch (error) {
      console.error('Logout error:', error)
    }
  }

  const handleLogoutClick = () => {
    setShowLogoutModal(true)
  }

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link href={isLoggedIn ? "/dashboard" : "/"} className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center">
              <span className="text-white font-light text-xl">D</span>
            </div>
            <span className="text-2xl font-light text-black">Dergi Rastgele</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-12">
            <Link href="/magazines" className="text-gray-700 hover:text-black transition-colors duration-300 font-light">
              Dergiler
            </Link>
            <Link href="/mini-series" className="text-gray-700 hover:text-black transition-colors duration-300 font-light">
              Mini Seriler
            </Link>
            {isLoggedIn && (
              <Link href="/library" className="text-gray-700 hover:text-black transition-colors duration-300 font-light">
                Kitaplığım
              </Link>
            )}
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-6">
            {isLoggedIn ? (
              <div className="relative profile-dropdown">
                {/* Profil Avatar + Kullanıcı Adı */}
                <button
                  onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                  className="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 transition-colors duration-300"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold text-sm">
                      {userName.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <span className="text-gray-700 font-medium">Merhaba, {userName}</span>
                  <svg 
                    className={`w-4 h-4 text-gray-500 transition-transform duration-200 ${showProfileDropdown ? 'rotate-180' : ''}`}
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {/* Dropdown Menu */}
                {showProfileDropdown && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-50">
                    <Link 
                      href="/profile" 
                      className="block px-4 py-3 text-gray-700 hover:bg-gray-50 hover:text-gray-900 transition-colors duration-200 font-medium"
                      onClick={() => setShowProfileDropdown(false)}
                    >
                      Profilim
                    </Link>
                    <Link 
                      href="/my-purchases" 
                      className="block px-4 py-3 text-gray-700 hover:bg-gray-50 hover:text-gray-900 transition-colors duration-200 font-medium"
                      onClick={() => setShowProfileDropdown(false)}
                    >
                      Satın Alma İşlemlerim
                    </Link>
                    {(userRoles.includes('admin') || userRoles.includes('owner')) && (
                      <Link 
                        href="/admin" 
                        className="block px-4 py-3 text-gray-700 hover:bg-gray-50 hover:text-gray-900 transition-colors duration-200 font-medium"
                        onClick={() => setShowProfileDropdown(false)}
                      >
                        Admin Paneli
                      </Link>
                    )}
                    {(userRoles.includes('moderator') || userRoles.includes('admin') || userRoles.includes('owner')) && (
                      <Link 
                        href="/test-moderation" 
                        className="block px-4 py-3 text-gray-700 hover:bg-gray-50 hover:text-gray-900 transition-colors duration-200 font-medium"
                        onClick={() => setShowProfileDropdown(false)}
                      >
                        Moderasyon
                      </Link>
                    )}
                    <div className="border-t border-gray-200 my-2"></div>
                    <button
                      onClick={() => {
                        setShowProfileDropdown(false)
                        handleLogoutClick()
                      }}
                      className="block w-full text-left px-4 py-3 text-red-600 hover:bg-red-50 hover:text-red-700 transition-colors duration-200 font-medium"
                    >
                      Çıkış
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link 
                  href="/auth/login" 
                  className="text-gray-700 hover:text-black transition-colors duration-300 font-light"
                >
                  Giriş
                </Link>
                <Link 
                  href="/auth/register" 
                  className="bg-black text-white px-6 py-2 hover:bg-gray-800 transition-colors duration-300 font-light"
                >
                  Üye Ol
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-black focus:outline-none focus:text-black transition-colors duration-300"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-gray-50 rounded-lg mt-2">
              <Link 
                href="/magazines" 
                className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                onClick={() => setIsMenuOpen(false)}
              >
                Dergiler
              </Link>
              <Link 
                href="/mini-series" 
                className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                onClick={() => setIsMenuOpen(false)}
              >
                Mini Seriler
              </Link>
              {isLoggedIn && (
                <Link 
                  href="/library" 
                  className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Kitaplığım
                </Link>
              )}
              {isLoggedIn ? (
                <div className="px-3 py-2 space-y-2">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-semibold text-sm">
                        {userName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <span className="text-gray-700 font-medium">Merhaba, {userName}</span>
                  </div>
                  
                  <Link 
                    href="/profile" 
                    className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Profilim
                  </Link>
                  <Link 
                    href="/my-purchases" 
                    className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Satın Alma İşlemlerim
                  </Link>
                  {(userRoles.includes('admin') || userRoles.includes('owner')) && (
                    <Link 
                      href="/admin" 
                      className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Admin Paneli
                    </Link>
                  )}
                  {(userRoles.includes('moderator') || userRoles.includes('admin') || userRoles.includes('owner')) && (
                    <Link 
                      href="/test-moderation" 
                      className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Moderasyon
                    </Link>
                  )}
                  <button
                    onClick={() => {
                      handleLogoutClick()
                      setIsMenuOpen(false)
                    }}
                    className="block w-full mt-2 border border-gray-300 text-gray-700 px-4 py-2 rounded hover:border-black hover:text-black transition-all duration-300 font-light"
                  >
                    Çıkış
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Link 
                    href="/auth/login" 
                    className="block px-3 py-2 text-gray-700 hover:text-black transition-colors duration-300 font-light"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Giriş
                  </Link>
                  <Link 
                    href="/auth/register" 
                    className="block mx-3 bg-black text-white px-4 py-2 hover:bg-gray-800 transition-colors duration-300 font-light text-center"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Üye Ol
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Logout Confirmation Modal */}
      {showLogoutModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Çıkış Yap</h3>
              <p className="text-gray-600 mb-8">
                Çıkış yapmak istediğinize emin misiniz?
              </p>
              <div className="flex space-x-4">
                <button
                  onClick={() => setShowLogoutModal(false)}
                  className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:border-gray-400 hover:bg-gray-50 transition-all duration-300 font-medium"
                >
                  Hayır
                </button>
                <button
                  onClick={handleLogout}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl hover:from-red-600 hover:to-red-700 transition-all duration-300 font-medium shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  Evet, Çıkış Yap
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}

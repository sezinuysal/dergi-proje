'use client'

import { useState, useEffect } from 'react'
import ProfileModerationPanel from '@/components/ProfileModerationPanel'

interface User {
  id: number
  name: string
  email: string
  avatar?: string
  bio?: string
  roles: Array<{
    role: {
      id: number
      name: string
      description: string
      color: string
      icon: string
    }
  }>
}

export default function TestModerationPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [currentUserRoles, setCurrentUserRoles] = useState<string[]>([])
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchCurrentUser()
    fetchAllUsers()
  }, [])

  const fetchCurrentUser = async () => {
    try {
      const response = await fetch('/api/auth/me')
      if (response.ok) {
        const user = await response.json()
        setCurrentUser(user)
        // Rolleri string array'e çevir
        const roleNames = user.roles ? user.roles.map((r: any) => r.role?.name || r.name || r) : []
        setCurrentUserRoles(roleNames)
      }
    } catch (error) {
      console.error('Error fetching current user:', error)
    }
  }

  const fetchAllUsers = async () => {
    try {
      const response = await fetch('/api/admin/users')
      if (response.ok) {
        const users = await response.json()
        setAllUsers(users)
      } else {
        console.error('Error fetching users:', response.statusText)
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    } finally {
      setLoading(false)
    }
  }



  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Erişim Reddedildi</h1>
            <p className="text-gray-600 mb-6">Moderasyon panelini görüntülemek için giriş yapmanız gerekiyor.</p>
            <a
              href="/auth/login"
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 inline-block"
            >
              Giriş Yap
            </a>
          </div>
        </div>
      </div>
    )
  }

  // Yetki kontrolü - sadece moderator, admin veya owner erişebilir
  const hasModerationAccess = currentUserRoles.some(role => 
    ['moderator', 'admin', 'owner'].includes(role.toLowerCase())
  )

  if (!hasModerationAccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Yetki Yetersiz</h1>
            <p className="text-gray-600 mb-2">Moderasyon paneline erişim yetkiniz bulunmuyor.</p>
            <p className="text-sm text-gray-500 mb-6">Mevcut rolleriniz: {currentUserRoles.join(', ') || 'Yok'}</p>
            <div className="space-y-3">
              <a
                href="/dashboard"
                className="block bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Ana Sayfaya Dön
              </a>
              <a
                href="/auth/logout"
                className="block border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-xl hover:border-gray-400 hover:bg-gray-50 transition-all duration-300 font-semibold"
              >
                Çıkış Yap
              </a>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-12">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-6">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Moderasyon Paneli</h1>
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 max-w-4xl mx-auto">
            <div className="flex items-center justify-center space-x-8 text-sm">
              <div className="text-center">
                <p className="text-gray-500">Giriş Yapan</p>
                <p className="font-semibold text-gray-900">{currentUser.name}</p>
              </div>
              <div className="w-px h-8 bg-gray-200"></div>
              <div className="text-center">
                <p className="text-gray-500">Roller</p>
                <p className="font-semibold text-gray-900">{currentUserRoles.join(', ')}</p>
              </div>
              <div className="w-px h-8 bg-gray-200"></div>
              <div className="text-center">
                <p className="text-gray-500">Toplam Kullanıcı</p>
                <p className="font-semibold text-gray-900">{allUsers.length}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-12">
          {/* Gerçek Kullanıcılar */}
          {allUsers.map((user, index) => (
            <div key={user.id}>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-green-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">{index + 1}</span>
                </div>
                <h2 className="text-2xl font-semibold text-gray-900">{user.name}</h2>
                <span className="text-sm text-gray-500">({user.email})</span>
              </div>
              <ProfileModerationPanel
                user={user}
                meRoles={currentUserRoles}
              />
            </div>
          ))}
        </div>

        {/* Yetki Bilgileri */}
        <div className="mt-16 bg-white rounded-2xl shadow-lg border border-gray-100 p-8">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-900">Yetki Bilgileri</h3>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-6 border border-yellow-200">
              <h4 className="font-semibold text-yellow-800 mb-2">Moderator+</h4>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• Uyarı verme</li>
                <li>• Geçici susturma</li>
                <li>• Rozet atama</li>
                <li>• Silme davası açma</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
              <h4 className="font-semibold text-blue-800 mb-2">Admin+</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Tüm moderator yetkileri</li>
                <li>• Rol yönetimi</li>
                <li>• Kullanıcı düzenleme</li>
                <li>• Sistem ayarları</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-200">
              <h4 className="font-semibold text-purple-800 mb-2">Owner</h4>
              <ul className="text-sm text-purple-700 space-y-1">
                <li>• Tüm yetkiler</li>
                <li>• Sistem yönetimi</li>
                <li>• Veritabanı erişimi</li>
                <li>• Tam kontrol</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

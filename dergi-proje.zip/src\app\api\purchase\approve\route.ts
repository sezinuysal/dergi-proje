import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { prisma } from "@/lib/prisma";
import { authOptions } from "@/lib/auth";
import { v4 as uuidv4 } from 'uuid';

export async function POST(req: Request) {
  const tokenExpiration = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000); // 1 year from now
  try {
    // Check if user is admin or moderator
    const session = await getServerSession(authOptions);
    if (!session || !session.user) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { roles: { include: { role: true } } },
    });

        const userRoles = user?.roles.map(role => role.role.name.toLowerCase()) || [];
    const hasPermission = userRoles.some((role) =>
      ["admin", "moderator", "yönetici"].includes(role)
    );

    if (!hasPermission) {
      return NextResponse.json(
        { error: "Yetkiniz yetersiz" },
        { status: 403 }
      );
    }

    const { purchaseRequestId } = await req.json();

    if (!purchaseRequestId) {
      return NextResponse.json(
        { error: "Satın alma talebi ID'si gereklidir" },
        { status: 400 }
      );
    }

    // Get the purchase request (publicationAccess tablosundan)
    const purchaseRequest = await prisma.publicationAccess.findUnique({
      where: { id: purchaseRequestId },
      include: {
        user: true,
        publication: true,
      },
    });

    if (!purchaseRequest) {
      return NextResponse.json(
        { error: "Satın alma talebi bulunamadı" },
        { status: 404 }
      );
    }

    // Start a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Update purchase status
      const updatedRequest = await tx.publicationAccess.update({
        where: { id: purchaseRequestId },
        data: { accessType: "read" },
        include: {
          user: true,
          publication: true,
        },
      });

      // Check if this is a magazine purchase that requires role assignment
      if (updatedRequest.publication.type === 'DIGITAL_MAGAZINE' || updatedRequest.publication.type === 'magazine') {
        // Find or create the subscriber role
        let subscriberRole = await tx.role.findUnique({
          where: { name: 'subscriber' },
        });

        if (!subscriberRole) {
          subscriberRole = await tx.role.create({
            data: {
              name: 'subscriber',
              description: 'Dijital dergi abonesi',
              color: '#4e73df',
              icon: 'newspaper',
              permissions: JSON.stringify(['read:magazines', 'download:magazines']),
            },
          });
        }

        // Check if user already has the subscriber role
        const hasSubscriberRole = await tx.userRole.findFirst({
          where: {
            userId: updatedRequest.userId,
            roleId: subscriberRole.id,
          },
        });

        // Assign subscriber role if not already assigned
        if (!hasSubscriberRole) {
          await tx.userRole.create({
            data: {
              userId: updatedRequest.userId,
              roleId: subscriberRole.id,
            },
          });
        }
      }

      // Generate a unique token for digital access
      const token = `DIGI-${uuidv4()}`;
      
      // Create digital access token
      await tx.accessToken.create({
        data: {
          userId: updatedRequest.userId,
          publicationId: updatedRequest.publicationId,
          token: token,
          permissions: JSON.stringify(["read"]),
          expiresAt: tokenExpiration,
        },
      });

      // Add to user's publications (kitaplık)
      await tx.publicationAccess.create({
        data: {
          userId: updatedRequest.userId,
          publicationId: updatedRequest.publicationId,
          accessType: "read",
          grantedAt: new Date(),
          expiresAt: tokenExpiration,
        },
      });

      return { success: true, token, userId: updatedRequest.userId };
    });

    return NextResponse.json({
      success: true,
      message: "Satın alma onaylandı ve dijital erişim sağlandı",
      token: result.token,
    });
  } catch (error) {
    console.error("Purchase approval error:", error);
    return NextResponse.json(
      { error: "İşlem sırasında bir hata oluştu" },
      { status: 500 }
    );
  }
}

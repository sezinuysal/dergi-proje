import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { cookies } from 'next/headers'
import { verifyToken } from '@/lib/session'
import { randomBytes } from 'crypto'

export async function POST(request: NextRequest) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { publicationId } = await request.json()

    if (!publicationId) {
      return NextResponse.json({ error: 'Publication ID is required' }, { status: 400 })
    }

    // Kullanıcıyı kontrol et
    const user = await prisma.user.findUnique({
      where: { id: payload.uid }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Dergiyi kontrol et
    const publication = await prisma.publication.findUnique({
      where: { id: publicationId }
    })

    if (!publication) {
      return NextResponse.json({ error: 'Publication not found' }, { status: 404 })
    }

    // Kullanıcının bu dergiye erişimi olup olmadığını kontrol et
    const existingAccess = await prisma.publicationAccess.findFirst({
      where: {
        userId: user.id,
        publicationId: publicationId,
        accessType: 'read'
      }
    })

    if (existingAccess) {
      return NextResponse.json({ error: 'Bu dergiye zaten erişiminiz var' }, { status: 400 })
    }

    // Benzersiz dijital token oluştur
    const digitalToken = `DIG_${randomBytes(16).toString('hex').toUpperCase()}`

    // Transaction ile satın alma işlemini gerçekleştir
    const result = await prisma.$transaction(async (tx) => {
      // PublicationAccess kaydını oluştur (dijital erişim)
      const publicationAccess = await tx.publicationAccess.create({
        data: {
          userId: user.id,
          publicationId: publicationId,
          accessType: 'read',
          grantedAt: new Date(),
          expiresAt: null // Sınırsız erişim
        }
      })

      // AccessToken kaydını oluştur
      const accessToken = await tx.accessToken.create({
        data: {
          userId: user.id,
          publicationId: publicationId,
          token: digitalToken,
          permissions: JSON.stringify(['read']),
          expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 yıl
        }
      })

      return {
        publicationAccess,
        accessToken
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Dijital dergi başarıyla satın alındı',
      token: digitalToken,
      purchase: {
        id: result.publicationAccess.id,
        publication: publication.title,
        purchaseDate: result.publicationAccess.grantedAt
      }
    })

  } catch (error) {
    console.error('Digital purchase error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

interface User {
  id: number
  name: string
  email: string
  bio?: string
  avatar?: string
  roles: Array<{
    role: {
      id: number
      name: string
      description: string
      color: string
      icon: string
    }
  }>
  badges: Array<{
    badge: {
      id: number
      name: string
      description: string
      icon: string
      color: string
      category: string
      rarity: string
    }
    earnedAt: string
  }>
}

interface UserStats {
  totalRead: number
  totalFavorites: number
  totalComments: number
  joinDate: string
}

export default function ProfilePage() {
  const [user, setUser] = useState<User | null>(null)
  const [stats, setStats] = useState<UserStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('library')
  const [showEditModal, setShowEditModal] = useState(false)
  const [editForm, setEditForm] = useState({
    name: '',
    bio: '',
    phone: '',
    newPassword: '',
    confirmPassword: ''
  })

  useEffect(() => {
    fetchUserProfile()
  }, [])

  const fetchUserProfile = async () => {
    try {
      const response = await fetch('/api/auth/me')
      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
        
        // Form verilerini doldur
        setEditForm({
          name: userData.name || '',
          bio: userData.bio || '',
          phone: userData.phone || '',
          newPassword: '',
          confirmPassword: ''
        })
        
        // Mock stats - gerçek uygulamada ayrı API'den gelecek
        setStats({
          totalRead: 12,
          totalFavorites: 8,
          totalComments: 24,
          joinDate: '2024-01-15'
        })
      }
    } catch (error) {
      console.error('Error fetching user profile:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleEditFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setEditForm(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Şifre kontrolü
    if (editForm.newPassword && editForm.newPassword !== editForm.confirmPassword) {
      alert('Şifreler eşleşmiyor')
      return
    }

    try {
      const response = await fetch('/api/user/update-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: editForm.name,
          bio: editForm.bio,
          phone: editForm.phone,
          password: editForm.newPassword || undefined
        }),
      })

      if (response.ok) {
        // Profili yeniden yükle
        await fetchUserProfile()
        setShowEditModal(false)
        alert('Profil başarıyla güncellendi')
      } else {
        alert('Profil güncellenirken hata oluştu')
      }
    } catch (error) {
      console.error('Error updating profile:', error)
      alert('Profil güncellenirken hata oluştu')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-light text-gray-800 mb-4">Giriş Yapın</h1>
          <p className="text-gray-600 mb-6">Profilinizi görüntülemek için giriş yapmanız gerekiyor.</p>
          <Link
            href="/auth/login"
            className="bg-black text-white px-6 py-3 rounded-md hover:bg-gray-800 transition-colors"
          >
            Giriş Yap
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex items-center space-x-6">
            {/* Avatar */}
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-24 h-24 rounded-full object-cover" />
              ) : (
                <span className="text-3xl text-gray-600 font-light">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              )}
            </div>

            {/* User Info */}
            <div className="flex-1">
              <h1 className="text-3xl font-light text-gray-900 mb-2">{user.name}</h1>
              <p className="text-gray-600 mb-3">{user.email}</p>
              {user.bio && (
                <p className="text-gray-700 mb-4 max-w-2xl">{user.bio}</p>
              )}

              {/* Roles */}
              <div className="flex flex-wrap gap-2 mb-4">
                {user.roles.map((userRole) => (
                  <span
                    key={userRole.role.id}
                    className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium"
                    style={{ 
                      backgroundColor: (userRole.role.color || '#6B7280') + '20',
                      color: userRole.role.color || '#6B7280'
                    }}
                  >
                    {userRole.role.name}
                  </span>
                ))}
              </div>

              {/* Stats */}
              {stats && (
                <div className="flex space-x-6 text-sm text-gray-600">
                  <span><strong>{stats.totalRead}</strong> okunan</span>
                  <span><strong>{stats.totalFavorites}</strong> favori</span>
                  <span><strong>{stats.totalComments}</strong> yorum</span>
                  <span>Üyelik: {new Date(stats.joinDate).toLocaleDateString('tr-TR')}</span>
                </div>
              )}
            </div>

            {/* Edit Profile Button */}
            <div>
              <button 
                onClick={() => setShowEditModal(true)}
                className="border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors"
              >
                Profili Düzenle
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-6xl mx-auto px-4">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8">
            {[
              { id: 'library', label: 'Kitaplığım', icon: '📚' },
              { id: 'favorites', label: 'Favoriler', icon: '❤️' },
              { id: 'badges', label: 'Rozetler', icon: '🏆' },
              { id: 'activity', label: 'Aktivite', icon: '📊' },
              { id: 'settings', label: 'Ayarlar', icon: '⚙️' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-black text-black'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="py-8">
          {activeTab === 'library' && <LibraryTab />}
          {activeTab === 'favorites' && <FavoritesTab />}
          {activeTab === 'badges' && <BadgesTab badges={user.badges} />}
          {activeTab === 'activity' && <ActivityTab />}
          {activeTab === 'settings' && <SettingsTab />}
        </div>
      </div>
    </div>
  )
}

// Kitaplık Tab
function LibraryTab() {
  const [libraryItems, setLibraryItems] = useState([
    {
      id: 1,
      title: 'Dijital Dergi Sayı 1',
      type: 'magazine',
      author: 'Dergi Rastgele',
      readStatus: 'completed',
      readProgress: 100,
      addedDate: '2024-01-20'
    },
    {
      id: 2,
      title: 'Teknoloji Serisi: Yapay Zeka',
      type: 'mini_series',
      author: 'AI Uzmanı',
      readStatus: 'reading',
      readProgress: 65,
      addedDate: '2024-01-18'
    }
  ])

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-light text-gray-900">Kitaplığım</h2>
        <div className="flex space-x-3">
          <select className="border border-gray-300 rounded-md px-3 py-2 text-sm">
            <option>Tümü</option>
            <option>Dergiler</option>
            <option>Mini Seriler</option>
            <option>Makaleler</option>
          </select>
          <select className="border border-gray-300 rounded-md px-3 py-2 text-sm">
            <option>Okuma Durumu</option>
            <option>Okundu</option>
            <option>Okunuyor</option>
            <option>Okunmadı</option>
          </select>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {libraryItems.map((item) => (
          <div key={item.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="font-medium text-gray-900 mb-1">{item.title}</h3>
                <p className="text-sm text-gray-600 mb-2">{item.author}</p>
                <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                  item.type === 'magazine' ? 'bg-blue-100 text-blue-800' :
                  item.type === 'mini_series' ? 'bg-purple-100 text-purple-800' :
                  'bg-green-100 text-green-800'
                }`}>
                  {item.type === 'magazine' ? 'Dergi' :
                   item.type === 'mini_series' ? 'Mini Seri' : 'Makale'}
                </span>
              </div>
              <button className="text-gray-400 hover:text-gray-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                </svg>
              </button>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>İlerleme</span>
                <span>{item.readProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-black h-2 rounded-full transition-all duration-300"
                  style={{ width: `${item.readProgress}%` }}
                ></div>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">
                {new Date(item.addedDate).toLocaleDateString('tr-TR')}
              </span>
              <div className="flex space-x-2">
                <button className="text-gray-400 hover:text-gray-600">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </button>
                <Link 
                  href={`/publication/${item.id}`}
                  className="bg-black text-white px-4 py-2 rounded-md text-sm hover:bg-gray-800 transition-colors"
                >
                  Oku
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// Favoriler Tab
function FavoritesTab() {
  return (
    <div>
      <h2 className="text-2xl font-light text-gray-900 mb-6">Favoriler</h2>
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-2xl">❤️</span>
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">Henüz favori içerik yok</h3>
        <p className="text-gray-600 mb-6">Beğendiğiniz içerikleri favorilere ekleyerek burada görüntüleyebilirsiniz.</p>
        <Link 
          href="/magazines"
          className="bg-black text-white px-6 py-3 rounded-md hover:bg-gray-800 transition-colors"
        >
          İçerikleri Keşfet
        </Link>
      </div>
    </div>
  )
}

// Rozetler Tab
function BadgesTab({ badges }: { badges: User['badges'] }) {
  return (
    <div>
      <h2 className="text-2xl font-light text-gray-900 mb-6">Rozetler</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {badges.map((userBadge) => (
          <div key={userBadge.badge.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: (userBadge.badge.color || '#6B7280') + '20' }}>
              <span className="text-2xl">{userBadge.badge.icon}</span>
            </div>
            <h3 className="font-medium text-gray-900 mb-2">{userBadge.badge.name}</h3>
            <p className="text-sm text-gray-600 mb-3">{userBadge.badge.description}</p>
            <div className="flex justify-center space-x-2">
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                userBadge.badge.rarity === 'legendary' ? 'bg-yellow-100 text-yellow-800' :
                userBadge.badge.rarity === 'epic' ? 'bg-purple-100 text-purple-800' :
                userBadge.badge.rarity === 'rare' ? 'bg-blue-100 text-blue-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {userBadge.badge.rarity === 'legendary' ? 'Efsanevi' :
                 userBadge.badge.rarity === 'epic' ? 'Epik' :
                 userBadge.badge.rarity === 'rare' ? 'Nadir' : 'Yaygın'}
              </span>
              <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                {userBadge.badge.category === 'role' ? 'Rol' : 'Başarım'}
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              Kazanıldı: {new Date(userBadge.earnedAt).toLocaleDateString('tr-TR')}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

// Aktivite Tab
function ActivityTab() {
  const activities = [
    {
      id: 1,
      type: 'read',
      title: 'Dijital Dergi Sayı 1',
      description: 'Dergiyi tamamladınız',
      date: '2024-01-20T10:30:00Z'
    },
    {
      id: 2,
      type: 'comment',
      title: 'Teknoloji Serisi: Yapay Zeka',
      description: 'Yazıya yorum yaptınız',
      date: '2024-01-19T15:45:00Z'
    },
    {
      id: 3,
      type: 'favorite',
      title: 'Mini Seri: Blockchain',
      description: 'İçeriği favorilere eklediniz',
      date: '2024-01-18T09:20:00Z'
    }
  ]

  return (
    <div>
      <h2 className="text-2xl font-light text-gray-900 mb-6">Aktivite Geçmişi</h2>
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                <span className="text-lg">
                  {activity.type === 'read' ? '📖' :
                   activity.type === 'comment' ? '💬' :
                   activity.type === 'favorite' ? '❤️' : '📝'}
                </span>
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-gray-900 mb-1">{activity.title}</h3>
                <p className="text-sm text-gray-600 mb-2">{activity.description}</p>
                <p className="text-xs text-gray-500">
                  {new Date(activity.date).toLocaleString('tr-TR')}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// Ayarlar Tab
function SettingsTab() {
  return (
    <div>
      <h2 className="text-2xl font-light text-gray-900 mb-6">Hesap Ayarları</h2>
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Profil Bilgileri</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Ad Soyad</label>
              <input 
                type="text" 
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                placeholder="Adınızı girin"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Biyografi</label>
              <textarea 
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                rows={3}
                placeholder="Kendiniz hakkında kısa bir açıklama yazın"
              />
            </div>
            <button className="bg-black text-white px-6 py-2 rounded-md hover:bg-gray-800 transition-colors">
              Kaydet
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Gizlilik Ayarları</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-900">Kitaplığımı herkese açık yap</h4>
                <p className="text-sm text-gray-600">Diğer kullanıcılar kitaplığınızı görebilir</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-black/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-900">Aktivite geçmişimi paylaş</h4>
                <p className="text-sm text-gray-600">Okuma aktiviteleriniz diğer kullanıcılara gösterilir</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-black/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Profil Düzenleme Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold text-gray-900">Profil Düzenle</h2>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                {/* Profil Fotoğrafı */}
                <div className="text-center">
                  <div className="w-32 h-32 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={user.name} className="w-32 h-32 rounded-full object-cover" />
                    ) : (
                      <span className="text-4xl text-white font-bold">
                        {user?.name?.charAt(0).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-300 text-sm font-medium shadow-lg hover:shadow-xl transform hover:scale-105">
                    Fotoğrafı Değiştir
                  </button>
                </div>

                {/* Profil Bilgileri */}
                <div className="md:col-span-2">
                  <form onSubmit={handleEditSubmit} className="space-y-6">
                    {/* Kişisel Bilgiler */}
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-4">Kişisel Bilgiler</h3>
                      <div className="space-y-4">
                        <div>
                          <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                            Ad Soyad
                          </label>
                          <input
                            type="text"
                            id="name"
                            name="name"
                            value={editForm.name}
                            onChange={handleEditFormChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300"
                            placeholder="Adınız Soyadınız"
                          />
                        </div>

                        <div>
                          <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                            E-posta
                          </label>
                          <input
                            type="email"
                            id="email"
                            value={user?.email || ''}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl bg-gray-50 text-gray-500 cursor-not-allowed"
                            readOnly
                          />
                          <p className="text-xs text-gray-500 mt-1">E-posta adresi değiştirilemez</p>
                        </div>

                        <div>
                          <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">
                            Telefon
                          </label>
                          <input
                            type="text"
                            id="phone"
                            name="phone"
                            value={editForm.phone}
                            onChange={handleEditFormChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300"
                            placeholder="Telefon numarası"
                          />
                        </div>

                        <div>
                          <label htmlFor="bio" className="block text-sm font-semibold text-gray-700 mb-2">
                            Biyografi
                          </label>
                          <textarea
                            id="bio"
                            name="bio"
                            value={editForm.bio}
                            onChange={handleEditFormChange}
                            rows={3}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300 resize-none"
                            placeholder="Kendiniz hakkında kısa bir açıklama yazın"
                          />
                        </div>
                      </div>
                    </div>

                    <hr className="border-gray-200" />

                    {/* Güvenlik */}
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-4">Güvenlik</h3>
                      <div className="space-y-4">
                        <div>
                          <label htmlFor="newPassword" className="block text-sm font-semibold text-gray-700 mb-2">
                            Yeni Şifre
                          </label>
                          <input
                            type="password"
                            id="newPassword"
                            name="newPassword"
                            value={editForm.newPassword}
                            onChange={handleEditFormChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300"
                            placeholder="Yeni şifre (boş bırakırsanız değişmez)"
                          />
                        </div>

                        <div>
                          <label htmlFor="confirmPassword" className="block text-sm font-semibold text-gray-700 mb-2">
                            Yeni Şifre (Tekrar)
                          </label>
                          <input
                            type="password"
                            id="confirmPassword"
                            name="confirmPassword"
                            value={editForm.confirmPassword}
                            onChange={handleEditFormChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300"
                            placeholder="Şifreyi tekrar girin"
                          />
                        </div>
                      </div>
                    </div>

                    <hr className="border-gray-200" />

                    {/* Butonlar */}
                    <div className="flex space-x-4">
                      <button
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
                      >
                        Kaydet
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowEditModal(false)}
                        className="flex-1 border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-2xl hover:border-gray-400 hover:bg-gray-50 transition-all duration-300 font-semibold"
                      >
                        Vazgeç
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

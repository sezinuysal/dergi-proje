import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { cookies } from 'next/headers'
import { verifyToken } from '@/lib/session'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Kullanıcıyı ve rollerini getir
    const user = await prisma.user.findUnique({
      where: { id: payload.uid },
      include: {
        roles: {
          include: {
            role: true
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Admin yetkisi kontrolü
    const isAdmin = user.roles.some(r => 
      ['admin', 'owner'].includes(r.role.name.toLowerCase())
    )

    if (!isAdmin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { role } = await request.json()
    const targetUserId = parseInt(params.id)

    if (!role) {
      return NextResponse.json({ error: 'Role is required' }, { status: 400 })
    }

    // Hedef kullanıcıyı getir
    const targetUser = await prisma.user.findUnique({
      where: { id: targetUserId },
      include: {
        roles: {
          include: {
            role: true
          }
        }
      }
    })

    if (!targetUser) {
      return NextResponse.json({ error: 'Target user not found' }, { status: 404 })
    }

    // Rolü bul
    const roleToAssign = await prisma.role.findUnique({
      where: { name: role }
    })

    if (!roleToAssign) {
      return NextResponse.json({ error: 'Role not found' }, { status: 404 })
    }

    // Kullanıcının bu role'ü zaten var mı kontrol et
    const existingRole = await prisma.userRole.findFirst({
      where: {
        userId: targetUserId,
        roleId: roleToAssign.id
      }
    })

    if (existingRole) {
      return NextResponse.json({ error: 'User already has this role' }, { status: 400 })
    }

    // Role'ü ata
    const userRole = await prisma.userRole.create({
      data: {
        userId: targetUserId,
        roleId: roleToAssign.id
      },
      include: {
        role: true
      }
    })

    return NextResponse.json({
      success: true,
      message: `${role} role assigned successfully`,
      userRole
    })
  } catch (error) {
    console.error('Error assigning role:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Kullanıcıyı ve rollerini getir
    const user = await prisma.user.findUnique({
      where: { id: payload.uid },
      include: {
        roles: {
          include: {
            role: true
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Admin yetkisi kontrolü
    const isAdmin = user.roles.some(r => 
      ['admin', 'owner'].includes(r.role.name.toLowerCase())
    )

    if (!isAdmin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { role } = await request.json()
    const targetUserId = parseInt(params.id)

    if (!role) {
      return NextResponse.json({ error: 'Role is required' }, { status: 400 })
    }

    // Hedef kullanıcıyı getir
    const targetUser = await prisma.user.findUnique({
      where: { id: targetUserId }
    })

    if (!targetUser) {
      return NextResponse.json({ error: 'Target user not found' }, { status: 404 })
    }

    // Rolü bul
    const roleToRemove = await prisma.role.findUnique({
      where: { name: role }
    })

    if (!roleToRemove) {
      return NextResponse.json({ error: 'Role not found' }, { status: 404 })
    }

    // Kullanıcının bu role'ü var mı kontrol et
    const existingRole = await prisma.userRole.findFirst({
      where: {
        userId: targetUserId,
        roleId: roleToRemove.id
      }
    })

    if (!existingRole) {
      return NextResponse.json({ error: 'User does not have this role' }, { status: 400 })
    }

    // Role'ü kaldır
    await prisma.userRole.delete({
      where: {
        id: existingRole.id
      }
    })

    return NextResponse.json({
      success: true,
      message: `${role} role removed successfully`
    })
  } catch (error) {
    console.error('Error removing role:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

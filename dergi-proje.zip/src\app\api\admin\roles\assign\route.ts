import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, JWTPayload } from "@/lib/session";
import { headers } from "next/headers";

export async function POST(req: Request) {
  try {
    const authorization = headers().get("authorization");
    if (!authorization) {
      return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
    }

    const token = authorization.split(" ")[1];
    const decoded = verifyToken(token);

    if (!decoded || !decoded.roles.includes("admin")) {
      return NextResponse.json({ error: "Yetkiniz yetersiz" }, { status: 403 });
    }


    const { userId, roleName } = await req.json();

    if (!userId || !roleName) {
      return NextResponse.json(
        { error: "Kullanıcı ID ve rol adı gereklidir" },
        { status: 400 }
      );
    }

    // Find or create the role
    let role = await prisma.role.findUnique({
      where: { name: roleName },
    });

    // If role doesn't exist, create it with default permissions
    if (!role) {
      const roleConfig: Record<string, { description: string; color: string; permissions: string[] }> = {
        admin: {
          description: 'Tam yönetici erişimi',
          color: '#e74a3b',
          permissions: ['*']
        },
        moderator: {
          description: 'İçerik yöneticisi',
          color: '#f6c23e',
          permissions: ['manage:content', 'manage:users', 'view:reports']
        },
        yönetici: {
          description: 'Sistem yöneticisi',
          color: '#1cc88a',
          permissions: ['*']
        }
      };

      const config = roleConfig[roleName.toLowerCase()];
      
      if (!config) {
        return NextResponse.json(
          { error: "Geçersiz rol adı" },
          { status: 400 }
        );
      }

      role = await prisma.role.create({
        data: {
          name: roleName,
          description: config.description,
          color: config.color,
          permissions: JSON.stringify(config.permissions),
          icon: roleName.toLowerCase() === 'moderator' ? 'shield' : 'star'
        },
      });
    }

    // Check if user already has this role
    const existingRole = await prisma.userRole.findFirst({
      where: {
        userId,
        roleId: role.id,
      },
    });

    if (existingRole) {
      return NextResponse.json(
        { error: "Kullanıcı zaten bu role sahip" },
        { status: 400 }
      );
    }

    // Assign the role
    await prisma.userRole.create({
      data: {
        userId,
        roleId: role.id,
      },
    });

    return NextResponse.json({
      success: true,
      message: `${roleName} rolü başarıyla atandı`,
    });
  } catch (error) {
    console.error("Role assignment error:", error);
    return NextResponse.json(
      { error: "Rol atanırken bir hata oluştu" },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { cookies } from 'next/headers'
import { verifyToken } from '@/lib/session'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Kullanıcıyı ve rollerini getir
    const user = await prisma.user.findUnique({
      where: { id: payload.uid },
      include: {
        roles: {
          include: {
            role: true
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Moderator yetkisi kontrolü
    const isModerator = user.roles.some(r => 
      ['moderator', 'admin', 'owner'].includes(r.role.name.toLowerCase())
    )

    if (!isModerator) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { badgeId } = await request.json()
    const targetUserId = parseInt(params.id)

    if (!badgeId) {
      return NextResponse.json({ error: 'Badge ID is required' }, { status: 400 })
    }

    // Hedef kullanıcıyı getir
    const targetUser = await prisma.user.findUnique({
      where: { id: targetUserId }
    })

    if (!targetUser) {
      return NextResponse.json({ error: 'Target user not found' }, { status: 404 })
    }

    // Rozeti bul
    const badge = await prisma.badge.findUnique({
      where: { id: badgeId }
    })

    if (!badge) {
      return NextResponse.json({ error: 'Badge not found' }, { status: 404 })
    }

    // Kullanıcının bu rozeti zaten var mı kontrol et
    const existingBadge = await prisma.userBadge.findFirst({
      where: {
        userId: targetUserId,
        badgeId: badgeId
      }
    })

    if (existingBadge) {
      return NextResponse.json({ error: 'User already has this badge' }, { status: 400 })
    }

    // Rozeti ata
    const userBadge = await prisma.userBadge.create({
      data: {
        userId: targetUserId,
        badgeId: badgeId,
        earnedAt: new Date()
      },
      include: {
        badge: true
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Rozet başarıyla atandı',
      userBadge
    })
  } catch (error) {
    console.error('Error assigning badge:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

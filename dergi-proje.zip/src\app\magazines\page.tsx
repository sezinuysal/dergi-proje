'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import PurchaseForm from '@/components/PurchaseForm'
import DigitalPurchaseModal from '@/components/DigitalPurchaseModal'

interface Publication {
  id: number
  title: string
  description: string | null
  type: string
  issue: string | null
  pageCount: number
  coverImage: string | null
  publishedAt: string | null
}

export default function MagazinesPage() {
  const [publications, setPublications] = useState<Publication[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'magazine' | 'mini_series'>('all')
  const [selectedPublication, setSelectedPublication] = useState<Publication | null>(null)
  const [showDigitalModal, setShowDigitalModal] = useState(false)

  useEffect(() => {
    fetchPublications()
  }, [])

  const fetchPublications = async () => {
    try {
      const response = await fetch('/api/publications')
      if (response.ok) {
        const data = await response.json()
        setPublications(data.publications)
      }
    } catch (error) {
      console.error('Error fetching publications:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredPublications = publications.filter(pub => {
    if (filter === 'all') return true
    return pub.type === filter
  })

  const handleDigitalPurchase = (publication: Publication) => {
    setSelectedPublication(publication)
    setShowDigitalModal(true)
  }

  const handlePurchaseSuccess = (token: string) => {
    console.log('Purchase successful, token:', token)
    setShowDigitalModal(false)
    setSelectedPublication(null)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-gray-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-8"></div>
          <p className="text-gray-600 font-medium text-lg">Dergiler yükleniyor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      {/* Header */}
      <div className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-transparent to-purple-50/30"></div>
        <div className="absolute top-10 right-10 w-72 h-72 bg-gradient-to-br from-blue-200/20 to-purple-200/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-8 shadow-lg">
            <span className="text-3xl">📚</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent mb-6 tracking-tight">
            Dijital Dergiler
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Sayfaları çevirerek okuyabileceğiniz, modern tasarım anlayışıyla hazırlanmış dijital dergiler
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          <button
            onClick={() => setFilter('all')}
            className={`px-8 py-4 font-semibold rounded-2xl transition-all duration-300 transform hover:scale-105 ${
              filter === 'all'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 shadow-md hover:shadow-lg'
            }`}
          >
            Tümü
          </button>
          <button
            onClick={() => setFilter('magazine')}
            className={`px-8 py-4 font-semibold rounded-2xl transition-all duration-300 transform hover:scale-105 ${
              filter === 'magazine'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 shadow-md hover:shadow-lg'
            }`}
          >
            Dergiler
          </button>
          <button
            onClick={() => setFilter('mini_series')}
            className={`px-8 py-4 font-semibold rounded-2xl transition-all duration-300 transform hover:scale-105 ${
              filter === 'mini_series'
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 shadow-md hover:shadow-lg'
            }`}
          >
            Mini Seriler
          </button>
        </div>

        {/* Publications Grid */}
        {filteredPublications.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-32 h-32 bg-gradient-to-br from-gray-100 to-gray-200 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-lg">
              <span className="text-4xl">📚</span>
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Henüz dergi yok</h3>
            <p className="text-gray-600 text-lg">Yakında yeni dergiler eklenecek</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPublications.map((publication) => (
              <div key={publication.id} className="group bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100 overflow-hidden">
                {/* Cover Image */}
                <div className="aspect-[3/4] bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden relative">
                  {publication.coverImage ? (
                    <img
                      src={publication.coverImage}
                      alt={publication.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-6xl text-gray-400">📖</span>
                    </div>
                  )}
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1.5 text-xs font-semibold rounded-full ${
                      publication.type === 'magazine' 
                        ? 'bg-blue-100 text-blue-800 border border-blue-200' 
                        : 'bg-purple-100 text-purple-800 border border-purple-200'
                    }`}>
                      {publication.type === 'magazine' ? 'Dergi' : 'Mini Seri'}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    {publication.issue && (
                      <span className="text-sm text-gray-500 font-medium">{publication.issue}</span>
                    )}
                    <span className="text-sm text-gray-500 font-medium">{publication.pageCount} sayfa</span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-3 leading-tight">{publication.title}</h3>
                  
                  {publication.description && (
                    <p className="text-gray-600 text-sm mb-6 leading-relaxed line-clamp-3">{publication.description}</p>
                  )}
                  
                  <div className="flex gap-3">
                    <Link
                      href={`/publication/${publication.id}`}
                      className="flex-1 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 px-4 py-3 text-sm font-semibold rounded-xl hover:from-gray-200 hover:to-gray-300 transition-all duration-300 text-center"
                    >
                      Önizleme
                    </Link>
                    <button
                      onClick={() => handleDigitalPurchase(publication)}
                      className="flex-1 bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-3 text-sm font-semibold rounded-xl hover:from-green-700 hover:to-green-800 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                      Dijital Satın Al
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Dijital Satın Alma Modal */}
      {selectedPublication && (
        <DigitalPurchaseModal
          isOpen={showDigitalModal}
          onClose={() => {
            setShowDigitalModal(false)
            setSelectedPublication(null)
          }}
          publication={selectedPublication}
          onSuccess={handlePurchaseSuccess}
        />
      )}
    </div>
  )
} 
'use client'

import { useState } from 'react'

interface PurchaseFormProps {
  publicationId: number
  publicationTitle: string
  onSuccess: () => void
}

export default function PurchaseForm({ publicationId, publicationTitle, onSuccess }: PurchaseFormProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    paymentMethod: 'credit_card',
    amount: '29.99',
    notes: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch('/api/purchase/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          publicationId,
          ...formData
        })
      })

      if (response.ok) {
        const result = await response.json()
        alert(result.message)
        onSuccess()
        setFormData({
          paymentMethod: 'credit_card',
          amount: '29.99',
          notes: ''
        })
      } else {
        const error = await response.json()
        alert(`Hata: ${error.error}`)
      }
    } catch (error) {
      alert('Bir hata oluştu. Lütfen tekrar deneyin.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <button
      onClick={handleSubmit}
      disabled={loading}
      className="bg-black text-white px-6 py-2 text-sm font-light hover:bg-gray-800 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {loading ? 'Gönderiliyor...' : 'Satın Al'}
    </button>
  )
} 
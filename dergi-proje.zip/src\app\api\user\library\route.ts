import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { cookies } from 'next/headers'
import { verifyToken } from '@/lib/session'

export async function GET(request: NextRequest) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Kullanıcının erişim hakları olan dergileri getir
    const libraryItems = await prisma.publicationAccess.findMany({
      where: {
        userId: payload.uid,
        accessType: 'read'
      },
      include: {
        publication: {
          select: {
            id: true,
            title: true,
            type: true,
            pageCount: true,
            coverImage: true,
            description: true
          }
        }
      },
      orderBy: {
        grantedAt: 'desc'
      }
    })

    // LibraryItem formatına dönüştür
    const formattedItems = libraryItems.map(item => ({
      id: item.id,
      publication: item.publication,
      addedAt: item.grantedAt.toISOString(),
      isFavorite: false, // Şimdilik false
      readProgress: 0, // Şimdilik 0
      lastReadAt: null, // Şimdilik null
      notes: null // Şimdilik null
    }))

    return NextResponse.json({
      success: true,
      items: formattedItems
    })

  } catch (error) {
    console.error('Error fetching library items:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

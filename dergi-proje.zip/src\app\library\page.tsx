'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

interface LibraryItem {
  id: number
  publication: {
    id: number
    title: string
    type: string
    pageCount: number
    coverImage: string | null
    description: string | null
  }
  addedAt: string
  isFavorite: boolean
  readProgress: number
  lastReadAt: string | null
  notes: string | null
}

export default function LibraryPage() {
  const [libraryItems, setLibraryItems] = useState<LibraryItem[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'magazine' | 'mini_series'>('all')
  const [sortBy, setSortBy] = useState<'added' | 'title' | 'progress'>('added')

  useEffect(() => {
    fetchLibraryItems()
  }, [])

  const fetchLibraryItems = async () => {
    try {
      const response = await fetch('/api/user/library')
      if (response.ok) {
        const data = await response.json()
        setLibraryItems(data.items || [])
      } else {
        console.error('Error fetching library items:', response.statusText)
      }
    } catch (error) {
      console.error('Error fetching library items:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredAndSortedItems = libraryItems
    .filter(item => {
      if (filter === 'all') return true
      return item.publication.type === filter
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a.publication.title.localeCompare(b.publication.title)
        case 'progress':
          return b.readProgress - a.readProgress
        case 'added':
        default:
          return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime()
      }
    })

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-gray-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-8"></div>
          <p className="text-gray-600 font-medium text-lg">Kitaplık yükleniyor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      {/* Header */}
      <div className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-transparent to-purple-50/30"></div>
        <div className="absolute top-10 right-10 w-72 h-72 bg-gradient-to-br from-blue-200/20 to-purple-200/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-8 shadow-lg">
            <span className="text-3xl">📚</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent mb-6 tracking-tight">
            Kitaplığım
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Satın aldığınız dijital dergiler ve okuma ilerlemeniz
          </p>
        </div>
      </div>

      {/* Filters and Sort */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex flex-wrap justify-between items-center gap-4 mb-8">
          {/* Filters */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setFilter('all')}
              className={`px-6 py-3 font-semibold rounded-xl transition-all duration-300 transform hover:scale-105 ${
                filter === 'all'
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 shadow-md hover:shadow-lg'
              }`}
            >
              Tümü ({libraryItems.length})
            </button>
            <button
              onClick={() => setFilter('magazine')}
              className={`px-6 py-3 font-semibold rounded-xl transition-all duration-300 transform hover:scale-105 ${
                filter === 'magazine'
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 shadow-md hover:shadow-lg'
              }`}
            >
              Dergiler ({libraryItems.filter(item => item.publication.type === 'magazine').length})
            </button>
            <button
              onClick={() => setFilter('mini_series')}
              className={`px-6 py-3 font-semibold rounded-xl transition-all duration-300 transform hover:scale-105 ${
                filter === 'mini_series'
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 shadow-md hover:shadow-lg'
              }`}
            >
              Mini Seriler ({libraryItems.filter(item => item.publication.type === 'mini_series').length})
            </button>
          </div>

          {/* Sort */}
          <div className="flex items-center space-x-3">
            <span className="text-sm font-medium text-gray-700">Sırala:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'added' | 'title' | 'progress')}
              className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-300"
            >
              <option value="added">Eklenme Tarihi</option>
              <option value="title">Başlık</option>
              <option value="progress">Okuma İlerlemesi</option>
            </select>
          </div>
        </div>

        {/* Library Items */}
        {filteredAndSortedItems.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-32 h-32 bg-gradient-to-br from-gray-100 to-gray-200 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-lg">
              <span className="text-4xl">📚</span>
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Kitaplığınız boş</h3>
            <p className="text-gray-600 text-lg mb-8">Henüz hiç dergi satın almadınız</p>
            <Link
              href="/magazines"
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <span className="mr-2">📖</span>
              Dergileri Keşfet
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredAndSortedItems.map((item) => (
              <div key={item.id} className="group bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100 overflow-hidden">
                {/* Cover Image */}
                <div className="aspect-[3/4] bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden relative">
                  {item.publication.coverImage ? (
                    <img
                      src={item.publication.coverImage}
                      alt={item.publication.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-6xl text-gray-400">📖</span>
                    </div>
                  )}
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1.5 text-xs font-semibold rounded-full ${
                      item.publication.type === 'magazine' 
                        ? 'bg-blue-100 text-blue-800 border border-blue-200' 
                        : 'bg-purple-100 text-purple-800 border border-purple-200'
                    }`}>
                      {item.publication.type === 'magazine' ? 'Dergi' : 'Mini Seri'}
                    </span>
                  </div>
                  {item.isFavorite && (
                    <div className="absolute top-4 right-4">
                      <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm">❤️</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm text-gray-500 font-medium">{item.publication.pageCount} sayfa</span>
                    <span className="text-sm text-gray-500 font-medium">
                      {new Date(item.addedAt).toLocaleDateString('tr-TR')}
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-3 leading-tight">{item.publication.title}</h3>
                  
                  {item.publication.description && (
                    <p className="text-gray-600 text-sm mb-4 leading-relaxed line-clamp-2">{item.publication.description}</p>
                  )}

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-1">
                      <span>Okuma İlerlemesi</span>
                      <span>{item.readProgress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${item.readProgress}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Last Read */}
                  {item.lastReadAt && (
                    <p className="text-xs text-gray-500 mb-4">
                      Son okuma: {new Date(item.lastReadAt).toLocaleDateString('tr-TR')}
                    </p>
                  )}

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button className="flex-1 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 px-4 py-3 text-sm font-semibold rounded-xl hover:from-gray-200 hover:to-gray-300 transition-all duration-300 text-center">
                      {item.readProgress === 0 ? 'Okumaya Başla' : 'Devam Et'}
                    </button>
                    <button className="px-4 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl hover:from-red-600 hover:to-pink-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
                      {item.isFavorite ? '❤️' : '🤍'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const publications = await prisma.publication.findMany({
      where: {
        isPublic: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json({
      success: true,
      publications
    })
  } catch (error) {
    console.error('Error fetching publications:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import RoleManagementModal from '@/components/RoleManagementModal'

export default function Dashboard() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedRole, setSelectedRole] = useState('')
  const [currentUserRoles, setCurrentUserRoles] = useState<string[]>([])
  const [currentUser, setCurrentUser] = useState<any>(null)

  useEffect(() => {
    // Kullanıcı rollerini kontrol et
    const checkUserRoles = async () => {
      try {
        const response = await fetch('/api/auth/me')
        if (response.ok) {
          const user = await response.json()
          setCurrentUser(user)
          if (user.roles) {
            setCurrentUserRoles(user.roles.map((r: any) => r.toLowerCase()))
          }
        }
      } catch (error) {
        console.log('User not logged in')
      }
    }
    
    checkUserRoles()
  }, [])

  const handleRoleCardClick = (roleName: string) => {
    // Yetki kontrolü
    const canAccess = currentUserRoles.includes('owner') || 
                     currentUserRoles.includes('admin') ||
                     (roleName === 'editor' && currentUserRoles.includes('editor')) ||
                     (roleName === 'moderator' && currentUserRoles.includes('moderator'))
    
    if (canAccess) {
      setSelectedRole(roleName)
      setIsModalOpen(true)
    } else {
      alert('Bu rolü yönetmek için yetkiniz bulunmuyor.')
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      {/* Hero Section - Modern */}
      <section className="relative py-24 px-4 overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-transparent to-purple-50/30"></div>
        <div className="absolute top-20 right-20 w-72 h-72 bg-gradient-to-br from-blue-200/20 to-purple-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-gradient-to-br from-green-200/20 to-blue-200/20 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-8 shadow-lg">
            <span className="text-3xl">📚</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent mb-6 tracking-tight">
            Dergi
            <span className="block text-4xl md:text-6xl font-light bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Rastgele</span>
          </h1>
          <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            Dijital dergi deneyimini yeniden tanımlıyoruz. 
            Sayfaları çevirerek okuyabileceğiniz, modern tasarım anlayışıyla hazırlanmış içerikler.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-8">
            <Link 
              href="/magazines" 
              className="group relative overflow-hidden bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 text-lg font-semibold rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 hover:shadow-xl"
            >
              <span className="relative z-10 flex items-center justify-center space-x-2">
                <span>Dergileri Keşfet</span>
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
            </Link>
            <Link 
              href="/my-purchases" 
              className="group relative overflow-hidden border-2 border-gray-300 text-gray-700 px-8 py-4 text-lg font-semibold rounded-2xl hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 transition-all duration-300 transform hover:scale-105"
            >
              <span className="relative z-10 flex items-center justify-center space-x-2">
                <span>Kitaplığım</span>
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </span>
            </Link>
          </div>
          {currentUser?.email === 'admin@dergi.local' && (
            <div className="mt-6">
              <Link 
                href="/test-moderation" 
                className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all duration-300 font-medium text-sm shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <span>🧪</span>
                <span>Moderasyon Test Paneli</span>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Üyelik Sistemi Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl mb-6 shadow-lg">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
              </svg>
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Üyelik Sistemi</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Farklı roller ve yetkilerle dijital dergi deneyimini kişiselleştirin
            </p>
          </div>
          
          {/* Roller Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
            {/* Owner */}
            <div 
              className="group cursor-pointer bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100"
              onClick={() => handleRoleCardClick('owner')}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <span className="text-3xl">👑</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Dergi Sahibi</h3>
              <p className="text-gray-600 mb-4">Tam yetki ve kontrol</p>
              <div className="flex items-center justify-center space-x-2">
                <div className="w-8 h-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full"></div>
                <span className="text-xs text-gray-500 font-medium">OWNER</span>
              </div>
            </div>

            {/* Admin */}
            <div 
              className="group cursor-pointer bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100"
              onClick={() => handleRoleCardClick('admin')}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-700 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <span className="text-3xl">🛡</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Yönetici</h3>
              <p className="text-gray-600 mb-4">Sistem yönetimi</p>
              <div className="flex items-center justify-center space-x-2">
                <div className="w-8 h-2 bg-gradient-to-r from-red-500 to-red-700 rounded-full"></div>
                <span className="text-xs text-gray-500 font-medium">ADMIN</span>
              </div>
            </div>

            {/* Editor */}
            <div 
              className="group cursor-pointer bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100"
              onClick={() => handleRoleCardClick('editor')}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <span className="text-3xl">✏️</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Editör</h3>
              <p className="text-gray-600 mb-4">İçerik yönetimi</p>
              <div className="flex items-center justify-center space-x-2">
                <div className="w-8 h-2 bg-gradient-to-r from-blue-600 to-blue-800 rounded-full"></div>
                <span className="text-xs text-gray-500 font-medium">EDITOR</span>
              </div>
            </div>

            {/* Moderator */}
            <div 
              className="group cursor-pointer bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100"
              onClick={() => handleRoleCardClick('moderator')}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <span className="text-3xl">🔍</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Moderatör</h3>
              <p className="text-gray-600 mb-4">İçerik moderasyonu</p>
              <div className="flex items-center justify-center space-x-2">
                <div className="w-8 h-2 bg-gradient-to-r from-purple-500 to-purple-700 rounded-full"></div>
                <span className="text-xs text-gray-500 font-medium">MODERATOR</span>
              </div>
            </div>
          </div>

          {/* Rozet Sistemi */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl mb-6 shadow-lg">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
              </svg>
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Rozet Sistemi</h3>
            <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto">
              YouTube tarzı rozet sistemi ile başarılarınızı gösterin ve yeni hedefler belirleyin
            </p>
            
            {/* Rozet Örnekleri */}
            <div className="grid md:grid-cols-3 gap-8">
              <div className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
                <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <span className="text-3xl">📚</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">İlk Dergi</h4>
                <p className="text-gray-600 mb-4">İlk dergiyi okudun</p>
                <span className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-green-100 to-green-200 text-green-800 text-sm font-semibold rounded-full border border-green-300">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Yaygın
                </span>
              </div>

              <div className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <span className="text-3xl">🏆</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">Dergi Tutkunu</h4>
                <p className="text-gray-600 mb-4">50 dergi okudun</p>
                <span className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 text-sm font-semibold rounded-full border border-blue-300">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  Efsanevi
                </span>
              </div>

              <div className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <span className="text-3xl">⭐</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">Mini Seri Ustası</h4>
                <p className="text-gray-600 mb-4">5 mini seri tamamladın</p>
                <span className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 text-sm font-semibold rounded-full border border-purple-300">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                  Epik
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Modern Grid */}
      <section className="py-20 px-4 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-2xl mb-6 shadow-lg">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Neler Sunuyoruz?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Modern teknoloji ile geliştirilmiş dijital okuma deneyimi
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                <span className="text-3xl text-white font-bold">01</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">Dijital Dergiler</h3>
              <p className="text-gray-600 leading-relaxed text-center">
                60-80 sayfalık interaktif dergiler, 
                modern tasarım anlayışıyla hazırlanmış
              </p>
            </div>
            
            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                <span className="text-3xl text-white font-bold">02</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">Mini Seriler</h3>
              <p className="text-gray-600 leading-relaxed text-center">
                410 sayfalık detaylı kitapçıklar, 
                derinlemesine içerik analizleri
              </p>
            </div>
            
            <div className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                <span className="text-3xl text-white font-bold">03</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">Kişisel Kitaplık</h3>
              <p className="text-gray-600 leading-relaxed text-center">
                Erişim hakkınız olan tüm yayınları 
                tek yerden yönetin
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Modern */}
      <section className="py-20 px-4 bg-gradient-to-br from-blue-600 via-purple-600 to-purple-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="absolute top-10 right-10 w-72 h-72 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-white/5 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Dijital Okuma Deneyimine Başlayın
          </h2>
          <p className="text-xl text-white/90 mb-12 leading-relaxed">
            Hemen üye olun ve modern tasarım anlayışıyla hazırlanmış 
            dijital dergi dünyasına adım atın
          </p>
          <Link 
            href="/magazines" 
            className="group inline-flex items-center space-x-3 bg-white text-gray-900 px-8 py-4 text-lg font-bold rounded-2xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl"
          >
            <span>Dergileri Keşfet</span>
            <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </Link>
        </div>
      </section>

      {/* Footer - Modern */}
      <footer className="py-16 px-4 bg-gray-900">
        <div className="max-w-6xl mx-auto text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-lg">
            <span className="text-white font-bold text-2xl">D</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">Dergi Rastgele</h3>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Modern teknoloji ile dijital okuma deneyimini yeniden tanımlıyoruz
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-8"></div>
          <p className="text-gray-500 text-sm">
            © 2024 Dergi Rastgele. Tüm hakları saklıdır.
          </p>
        </div>
      </footer>

      {/* Role Management Modal */}
      <RoleManagementModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        selectedRole={selectedRole}
        currentUserRoles={currentUserRoles}
      />
    </main>
  )
}

'use client'

import { useState, useEffect } from 'react'

interface User {
  id: number
  name: string
  email: string
  roles: Array<{
    role: {
      id: number
      name: string
      description: string
      color: string
      icon: string
    }
  }>
}

interface Role {
  id: number
  name: string
  description: string
  color: string
  icon: string
}

interface RoleManagementModalProps {
  isOpen: boolean
  onClose: () => void
  selectedRole: string
  currentUserRoles: string[]
}

export default function RoleManagementModal({ 
  isOpen, 
  onClose, 
  selectedRole, 
  currentUserRoles 
}: RoleManagementModalProps) {
  const [users, setUsers] = useState<User[]>([])
  const [roles, setRoles] = useState<Role[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<'individual' | 'bulk'>('individual')

  useEffect(() => {
    if (isOpen) {
      fetchData()
    }
  }, [isOpen])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [usersRes, rolesRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/admin/roles')
      ])

      if (usersRes.ok) {
        const usersData = await usersRes.json()
        setUsers(usersData)
      }

      if (rolesRes.ok) {
        const rolesData = await rolesRes.json()
        setRoles(rolesData)
      }
    } catch (error) {
      console.error('Veri yüklenirken hata:', error)
    }
    setLoading(false)
  }

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleAssignRole = async (userId: number, roleName: string) => {
    try {
      const response = await fetch(`/api/admin/users/${userId}/roles`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ role: roleName }),
      })

      if (response.ok) {
        alert(`${roleName} rolü başarıyla atandı!`)
        fetchData() // Verileri yenile
      } else {
        const error = await response.json()
        alert(`Hata: ${error.error}`)
      }
    } catch (error) {
      console.error('Rol atama hatası:', error)
      alert('Rol atanırken bir hata oluştu')
    }
  }

  const handleRemoveRole = async (userId: number, roleName: string) => {
    try {
      const response = await fetch(`/api/admin/users/${userId}/roles`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ role: roleName }),
      })

      if (response.ok) {
        alert(`${roleName} rolü başarıyla kaldırıldı!`)
        fetchData() // Verileri yenile
      } else {
        const error = await response.json()
        alert(`Hata: ${error.error}`)
      }
    } catch (error) {
      console.error('Rol kaldırma hatası:', error)
      alert('Rol kaldırılırken bir hata oluştu')
    }
  }

  const canManageRole = (roleName: string) => {
    // Owner her rolü yönetebilir
    if (currentUserRoles.includes('owner')) return true
    
    // Admin sadece editor, moderator, author, subscriber, member yönetebilir
    if (currentUserRoles.includes('admin')) {
      return ['editor', 'moderator', 'author', 'subscriber', 'member'].includes(roleName.toLowerCase())
    }
    
    return false
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-light text-gray-800">
              {selectedRole} Rol Yönetimi
            </h2>
            <p className="text-gray-600 mt-1">
              Bu role sahip kullanıcıları yönetin
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Tabs */}
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex space-x-1">
            <button
              onClick={() => setActiveTab('individual')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'individual' 
                  ? 'bg-black text-white' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Bireysel Yönetim
            </button>
            <button
              onClick={() => setActiveTab('bulk')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'bulk' 
                  ? 'bg-black text-white' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Toplu Atama
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
            </div>
          ) : (
            <>
              {/* Search */}
              <div className="mb-6">
                <input
                  type="text"
                  placeholder="Kullanıcı ara (ad veya email)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                />
              </div>

              {/* Users List */}
              <div className="space-y-4">
                {filteredUsers.map((user) => {
                  const userRoleNames = user.roles.map(r => r.role.name.toLowerCase())
                  const hasSelectedRole = userRoleNames.includes(selectedRole.toLowerCase())
                  
                  return (
                    <div key={user.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-medium text-gray-900">{user.name}</h3>
                          <p className="text-sm text-gray-600">{user.email}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          {user.roles.map((userRole) => (
                            <span
                              key={userRole.role.id}
                              className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                              style={{ 
                                backgroundColor: userRole.role.color + '20',
                                color: userRole.role.color 
                              }}
                            >
                              {userRole.role.name}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Role Actions */}
                      {canManageRole(selectedRole) && (
                        <div className="flex gap-2">
                          {!hasSelectedRole ? (
                            <button
                              onClick={() => handleAssignRole(user.id, selectedRole)}
                              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm"
                            >
                              {selectedRole} Rolü Ver
                            </button>
                          ) : (
                            <button
                              onClick={() => handleRemoveRole(user.id, selectedRole)}
                              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors text-sm"
                            >
                              {selectedRole} Rolünü Kaldır
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>

              {filteredUsers.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500">Kullanıcı bulunamadı</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:border-black hover:text-black transition-all duration-300"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  )
}

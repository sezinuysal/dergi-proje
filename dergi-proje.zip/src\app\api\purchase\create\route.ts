import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { cookies } from 'next/headers'
import { verifyToken } from '@/lib/session'

export async function POST(request: NextRequest) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { publicationId, paymentMethod, amount, notes } = await request.json()

    if (!publicationId) {
      return NextResponse.json({ error: 'Publication ID is required' }, { status: 400 })
    }

    // Satın alma isteği oluştur (publicationAccess tablosunda)
    const purchaseRequest = await prisma.publicationAccess.create({
      data: {
        userId: payload.uid,
        publicationId: publicationId,
        accessType: 'PENDING', // Beklemede
        grantedAt: new Date(),
        expiresAt: null // Henüz belirlenmedi
      },
      include: {
        user: true,
        publication: true
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Satın alma isteğiniz alındı! Admin onayı bekleniyor.',
      request: purchaseRequest
    })
  } catch (error) {
    console.error('Error creating purchase request:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
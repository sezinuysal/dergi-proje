import "./globals.css";
import Navbar from "@/components/Navbar";

export const metadata = {
  title: "Dergi Rastgele",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="tr">
      <body>
        <Navbar />
        {children}
      </body>
    </html>
  );
}

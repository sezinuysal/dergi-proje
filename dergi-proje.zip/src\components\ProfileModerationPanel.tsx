'use client'

import { useState } from 'react'

interface User {
  id: number
  name: string
  email: string
  avatar?: string
  bio?: string
  roles: Array<{
    role: {
      id: number
      name: string
      description: string
      color: string
      icon: string
    }
  }>
}

interface ProfileModerationPanelProps {
  user: User
  meRoles: string[]
}

export default function ProfileModerationPanel({ user, meRoles }: ProfileModerationPanelProps) {
  const [showWarnModal, setShowWarnModal] = useState(false)
  const [showMuteModal, setShowMuteModal] = useState(false)
  const [showBadgePicker, setShowBadgePicker] = useState(false)
  const [showRoleManager, setShowRoleManager] = useState(false)
  const [showCaseBanner, setShowCaseBanner] = useState(false)
  const [pendingDeleteCase, setPendingDeleteCase] = useState({
    id: 1,
    approvals: 2,
    required: 3
  })

  // Yetki kontrolü fonksiyonları
  const isModerator = meRoles.some(role => {
    const roleName = typeof role === 'string' ? role : role.role?.name || role.name
    return ['moderator', 'admin', 'owner'].includes(roleName.toLowerCase())
  })
  const isAdmin = meRoles.some(role => {
    const roleName = typeof role === 'string' ? role : role.role?.name || role.name
    return ['admin', 'owner'].includes(roleName.toLowerCase())
  })
  const isOwner = meRoles.some(role => {
    const roleName = typeof role === 'string' ? role : role.role?.name || role.name
    return roleName.toLowerCase() === 'owner'
  })

  // API çağrıları
  const handleWarn = async (reason: string) => {
    try {
      const response = await fetch(`/api/mod/users/${user.id}/warn`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      })
      
      if (response.ok) {
        // Toast göster
        alert('Kullanıcı uyarıldı!')
        setShowWarnModal(false)
      }
    } catch (error) {
      alert('Uyarı gönderilirken hata oluştu')
    }
  }

  const handleMute = async (duration: number, reason: string) => {
    try {
      const response = await fetch(`/api/mod/users/${user.id}/mute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ duration, reason })
      })
      
      if (response.ok) {
        alert('Kullanıcı susturuldu!')
        setShowMuteModal(false)
      }
    } catch (error) {
      alert('Susturma işleminde hata oluştu')
    }
  }

  const handleBadgeAssign = async (badgeId: number) => {
    try {
      const response = await fetch(`/api/mod/users/${user.id}/badge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ badgeId })
      })
      
      if (response.ok) {
        alert('Rozet atandı!')
        setShowBadgePicker(false)
      }
    } catch (error) {
      alert('Rozet atanırken hata oluştu')
    }
  }

  const handleRoleChange = async (action: 'add' | 'remove', roleName: string) => {
    try {
      const response = await fetch(`/api/admin/users/${user.id}/roles`, {
        method: action === 'add' ? 'POST' : 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: roleName })
      })
      
      if (response.ok) {
        alert(`Rol ${action === 'add' ? 'atandı' : 'kaldırıldı'}!`)
        setShowRoleManager(false)
      }
    } catch (error) {
      alert('Rol işleminde hata oluştu')
    }
  }

  const handleDeleteCase = async () => {
    try {
      const response = await fetch(`/api/mod/users/${user.id}/delete-case`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: 'Moderasyon gerekçesi' })
      })
      
      if (response.ok) {
        alert('Silme davası açıldı!')
        setShowCaseBanner(true)
      }
    } catch (error) {
      alert('Silme davası açılırken hata oluştu')
    }
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 hover:shadow-xl transition-all duration-300">
      {/* Kullanıcı Bilgileri */}
      <div className="flex items-center space-x-6 mb-8">
        <div className="relative">
          <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center shadow-md">
            {user.avatar ? (
              <img src={user.avatar} alt={user.name} className="w-20 h-20 rounded-2xl object-cover" />
            ) : (
              <span className="text-3xl text-gray-600 font-medium">
                {user.name.charAt(0).toUpperCase()}
              </span>
            )}
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white"></div>
        </div>
        <div className="flex-1">
          <h3 className="text-2xl font-semibold text-gray-900 mb-1">{user.name}</h3>
          <p className="text-gray-500 mb-3">{user.email}</p>
          <div className="flex flex-wrap gap-2">
            {user.roles.map((userRole) => (
              <span
                key={userRole.role.id}
                className="inline-flex items-center px-3 py-1.5 rounded-full text-sm font-medium shadow-sm"
                style={{ 
                  backgroundColor: (userRole.role.color || '#6B7280') + '15',
                  color: userRole.role.color || '#6B7280',
                  border: `1px solid ${(userRole.role.color || '#6B7280')}30`
                }}
              >
                <span className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: userRole.role.color || '#6B7280' }}></span>
                {userRole.role.name}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Bekleyen Silme Davası Banner */}
      {showCaseBanner && (
        <div className="mb-8 p-6 bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-red-800">Bekleyen Silme Davası</h4>
                <p className="text-sm text-red-600">
                  Onaylar: <span className="font-medium">{pendingDeleteCase.approvals}/{pendingDeleteCase.required}</span>
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowCaseBanner(false)}
              className="p-2 text-red-400 hover:text-red-600 hover:bg-red-100 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Moderasyon Butonları */}
      <div className="space-y-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
            <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h4 className="text-xl font-semibold text-gray-900">Moderasyon İşlemleri</h4>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Uyarı Butonu - Moderator+ */}
          {isModerator && (
            <button
              onClick={() => setShowWarnModal(true)}
              className="group relative overflow-hidden bg-gradient-to-br from-yellow-500 to-yellow-600 text-white rounded-2xl p-6 hover:from-yellow-600 hover:to-yellow-700 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <div className="text-left">
                  <h5 className="font-semibold text-lg">Uyarı Ver</h5>
                  <p className="text-yellow-100 text-sm">Kullanıcıyı uyar</p>
                </div>
              </div>
            </button>
          )}

          {/* Susturma Butonu - Moderator+ */}
          {isModerator && (
            <button
              onClick={() => setShowMuteModal(true)}
              className="group relative overflow-hidden bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-2xl p-6 hover:from-orange-600 hover:to-orange-700 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                  </svg>
                </div>
                <div className="text-left">
                  <h5 className="font-semibold text-lg">Sustur</h5>
                  <p className="text-orange-100 text-sm">Geçici susturma</p>
                </div>
              </div>
            </button>
          )}

          {/* Rozet Atama - Moderator+ */}
          {isModerator && (
            <button
              onClick={() => setShowBadgePicker(true)}
              className="group relative overflow-hidden bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-2xl p-6 hover:from-purple-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                  </svg>
                </div>
                <div className="text-left">
                  <h5 className="font-semibold text-lg">Rozet Ata</h5>
                  <p className="text-purple-100 text-sm">Başarım rozeti</p>
                </div>
              </div>
            </button>
          )}

          {/* Rol Yönetimi - Admin+ */}
          {isAdmin && (
            <button
              onClick={() => setShowRoleManager(true)}
              className="group relative overflow-hidden bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl p-6 hover:from-blue-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                  </svg>
                </div>
                <div className="text-left">
                  <h5 className="font-semibold text-lg">Rol Yönet</h5>
                  <p className="text-blue-100 text-sm">Yetki atama</p>
                </div>
              </div>
            </button>
          )}

          {/* Silme Davası - Moderator+ */}
          {isModerator && (
            <button
              onClick={handleDeleteCase}
              className="group relative overflow-hidden bg-gradient-to-br from-red-500 to-red-600 text-white rounded-2xl p-6 hover:from-red-600 hover:to-red-700 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </div>
                <div className="text-left">
                  <h5 className="font-semibold text-lg">Silme Davası</h5>
                  <p className="text-red-100 text-sm">Kalıcı silme</p>
                </div>
              </div>
            </button>
          )}
        </div>
      </div>

      {/* Modallar */}
      {showWarnModal && (
        <WarnModal
          user={user}
          onClose={() => setShowWarnModal(false)}
          onWarn={handleWarn}
        />
      )}

      {showMuteModal && (
        <MuteModal
          user={user}
          onClose={() => setShowMuteModal(false)}
          onMute={handleMute}
        />
      )}

      {showBadgePicker && (
        <BadgePicker
          user={user}
          onClose={() => setShowBadgePicker(false)}
          onAssign={handleBadgeAssign}
        />
      )}

      {showRoleManager && (
        <RoleManager
          user={user}
          onClose={() => setShowRoleManager(false)}
          onChange={handleRoleChange}
        />
      )}
    </div>
  )
}

// Uyarı Modal'ı
function WarnModal({ user, onClose, onWarn }: { user: User, onClose: () => void, onWarn: (reason: string) => void }) {
  const [reason, setReason] = useState('')

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Uyarı Ver</h3>
        <p className="text-sm text-gray-600 mb-4">{user.name} kullanıcısına uyarı vermek istediğinizden emin misiniz?</p>
        
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Uyarı gerekçesi..."
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500 mb-4"
          rows={3}
        />
        
        <div className="flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
          >
            İptal
          </button>
          <button
            onClick={() => onWarn(reason)}
            className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700"
          >
            Uyarı Ver
          </button>
        </div>
      </div>
    </div>
  )
}

// Susturma Modal'ı
function MuteModal({ user, onClose, onMute }: { user: User, onClose: () => void, onMute: (duration: number, reason: string) => void }) {
  const [duration, setDuration] = useState(1)
  const [reason, setReason] = useState('')

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Kullanıcıyı Sustur</h3>
        <p className="text-sm text-gray-600 mb-4">{user.name} kullanıcısını susturmak istediğinizden emin misiniz?</p>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">Süre (gün)</label>
          <select
            value={duration}
            onChange={(e) => setDuration(parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
          >
            <option value={1}>1 Gün</option>
            <option value={3}>3 Gün</option>
            <option value={7}>1 Hafta</option>
            <option value={30}>1 Ay</option>
          </select>
        </div>
        
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Susturma gerekçesi..."
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 mb-4"
          rows={3}
        />
        
        <div className="flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
          >
            İptal
          </button>
          <button
            onClick={() => onMute(duration, reason)}
            className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700"
          >
            Sustur
          </button>
        </div>
      </div>
    </div>
  )
}

// Rozet Seçici Drawer
function BadgePicker({ user, onClose, onAssign }: { user: User, onClose: () => void, onAssign: (badgeId: number) => void }) {
  const badges = [
    { id: 1, name: 'İlk Dergi', icon: '📚', color: 'green' },
    { id: 2, name: 'Düzenli Okuyucu', icon: '📖', color: 'blue' },
    { id: 3, name: 'Dergi Tutkunu', icon: '🏆', color: 'purple' },
    { id: 4, name: 'Mini Seri Ustası', icon: '⭐', color: 'yellow' }
  ]

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50">
      <div className="bg-white rounded-t-lg shadow-xl max-w-md w-full max-h-[80vh] overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">Rozet Seç</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
        
        <div className="p-4 overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            {badges.map((badge) => (
              <button
                key={badge.id}
                onClick={() => onAssign(badge.id)}
                className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-center"
              >
                <div className="text-2xl mb-2">{badge.icon}</div>
                <div className="text-sm font-medium text-gray-900">{badge.name}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// Rol Yöneticisi Modal'ı
function RoleManager({ user, onClose, onChange }: { user: User, onClose: () => void, onChange: (action: 'add' | 'remove', roleName: string) => void }) {
  const availableRoles = [
    { name: 'editor', displayName: 'Editör' },
    { name: 'moderator', displayName: 'Moderatör' },
    { name: 'author', displayName: 'Yazar' },
    { name: 'subscriber', displayName: 'Abone' },
    { name: 'member', displayName: 'Üye' }
  ]

  const userRoleNames = user.roles.map(r => r.role.name.toLowerCase())

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Rol Yönetimi</h3>
        <p className="text-sm text-gray-600 mb-4">{user.name} kullanıcısının rollerini yönetin</p>
        
        <div className="space-y-3">
          {availableRoles.map((role) => {
            const hasRole = userRoleNames.includes(role.name)
            return (
              <div key={role.name} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <span className="font-medium text-gray-900">{role.displayName}</span>
                {hasRole ? (
                  <button
                    onClick={() => onChange('remove', role.name)}
                    className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                  >
                    Kaldır
                  </button>
                ) : (
                  <button
                    onClick={() => onChange('add', role.name)}
                    className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
                  >
                    Ekle
                  </button>
                )}
              </div>
            )
          })}
        </div>
        
        <div className="flex justify-end mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  )
}

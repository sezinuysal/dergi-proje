import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { cookies } from 'next/headers'
import { verifyToken } from '@/lib/session'

export async function GET(request: NextRequest) {
  try {
    // Cookie'den session'ı oku
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')
    
    if (!sessionCookie?.value) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // JWT token'ı verify et
    const payload = verifyToken(sessionCookie.value)
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Kullanıcının dijital erişim token'larını getir
    const digitalTokens = await prisma.publicationAccess.findMany({
      where: {
        userId: payload.uid
      },
      include: {
        publication: {
          select: {
            id: true,
            title: true,
            type: true,
            coverImage: true
          }
        }
      },
      orderBy: {
        grantedAt: 'desc'
      }
    })

    // Token'ları dönüştür
    const tokens = digitalTokens.map(access => ({
      id: access.id,
      publicationId: access.publicationId,
      token: `DIGI-${access.id}-${access.userId}`, // Basit token formatı
      accessType: access.accessType,
      expiresAt: access.expiresAt,
      createdAt: access.grantedAt,
      publication: access.publication
    }))

    return NextResponse.json(tokens)
  } catch (error) {
    console.error('Error fetching digital tokens:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
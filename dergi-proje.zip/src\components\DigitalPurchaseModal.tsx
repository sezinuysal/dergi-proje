'use client'

import { useState } from 'react'

interface DigitalPurchaseModalProps {
  isOpen: boolean
  onClose: () => void
  publication: {
    id: number
    title: string
    type: string
    pageCount: number
    coverImage?: string | null
  }
  onSuccess: (token: string) => void
}

export default function DigitalPurchaseModal({ 
  isOpen, 
  onClose, 
  publication, 
  onSuccess 
}: DigitalPurchaseModalProps) {
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState<'confirm' | 'processing' | 'success'>('confirm')
  const [digitalToken, setDigitalToken] = useState('')

  if (!isOpen) return null

  const handlePurchase = async () => {
    setLoading(true)
    setStep('processing')

    try {
      const response = await fetch('/api/digital-purchase', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          publicationId: publication.id
        })
      })

      if (response.ok) {
        const result = await response.json()
        setDigitalToken(result.token)
        setStep('success')
        onSuccess(result.token)
      } else {
        const error = await response.json()
        alert(`Hata: ${error.error}`)
        setStep('confirm')
      }
    } catch (error) {
      alert('Bir hata oluştu. Lütfen tekrar deneyin.')
      setStep('confirm')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setStep('confirm')
    setDigitalToken('')
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl">
        {step === 'confirm' && (
          <div className="p-8">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Dijital Dergi Satın Al</h2>
              <p className="text-gray-600">Bu dergiyi dijital olarak satın almak istediğinize emin misiniz?</p>
            </div>

            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <div className="flex items-center space-x-4">
                {publication.coverImage ? (
                  <img 
                    src={publication.coverImage} 
                    alt={publication.title}
                    className="w-16 h-20 object-cover rounded-lg"
                  />
                ) : (
                  <div className="w-16 h-20 bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">📖</span>
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{publication.title}</h3>
                  <p className="text-sm text-gray-600">{publication.type === 'magazine' ? 'Dergi' : 'Mini Seri'}</p>
                  <p className="text-sm text-gray-500">{publication.pageCount} sayfa</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-semibold text-blue-900 mb-1">Dijital Satın Alma</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Anında kitaplığınıza eklenir</li>
                    <li>• Benzersiz erişim tokeni alırsınız</li>
                    <li>• Sınırsız okuma hakkı</li>
                    <li>• Mobil ve masaüstü uyumlu</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={handleClose}
                className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:border-gray-400 hover:bg-gray-50 transition-all duration-300 font-semibold"
              >
                İptal
              </button>
              <button
                onClick={handlePurchase}
                disabled={loading}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-xl hover:from-green-700 hover:to-green-800 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {loading ? 'İşleniyor...' : 'Satın Al (₺29.99)'}
              </button>
            </div>
          </div>
        )}

        {step === 'processing' && (
          <div className="p-8 text-center">
            <div className="w-16 h-16 border-4 border-gray-200 border-t-green-600 rounded-full animate-spin mx-auto mb-6"></div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Satın Alma İşleniyor</h2>
            <p className="text-gray-600">Dijital dergi kitaplığınıza ekleniyor...</p>
          </div>
        )}

        {step === 'success' && (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Satın Alma Başarılı!</h2>
            <p className="text-gray-600 mb-4">Dijital dergi kitaplığınıza eklendi.</p>
            
            <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
              <h4 className="font-semibold text-green-900 mb-2">Erişim Tokeni</h4>
              <div className="bg-white border border-green-300 rounded-lg p-3">
                <code className="text-sm text-green-800 font-mono break-all">{digitalToken}</code>
              </div>
              <p className="text-xs text-green-700 mt-2">Bu token ile dergiye erişebilirsiniz</p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={handleClose}
                className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:border-gray-400 hover:bg-gray-50 transition-all duration-300 font-semibold"
              >
                Kapat
              </button>
              <button
                onClick={() => window.location.href = '/library'}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Kitaplığım
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
